
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { History, Calendar, Code, Bug, Download, Eye, Trash2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface CodeSession {
  id: string;
  code_content: string;
  language: string;
  analysis_results: any;
  fix_results: any;
  created_at: string;
}

const HistoryPanel = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [history, setHistory] = useState<CodeSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchHistory();
    }
  }, [user]);

  const fetchHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('code_sessions')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setHistory(data || []);
    } catch (error) {
      console.error('Error fetching history:', error);
      toast({
        title: "Error",
        description: "Failed to load history.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (session: CodeSession) => {
    if (session.fix_results) return "bg-green-600";
    if (session.analysis_results) return "bg-yellow-600";
    return "bg-gray-600";
  };

  const getStatusText = (session: CodeSession) => {
    if (session.fix_results) return "Fixed";
    if (session.analysis_results) return "Analyzed";
    return "Pending";
  };

  const downloadCode = (session: CodeSession) => {
    const element = document.createElement("a");
    const file = new Blob([session.code_content], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `code_${session.id.slice(0, 8)}.${session.language === 'javascript' ? 'js' : session.language === 'python' ? 'py' : 'c'}`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    toast({
      title: "Downloaded!",
      description: "Code file has been downloaded.",
    });
  };

  const deleteSession = async (sessionId: string) => {
    try {
      const { error } = await supabase
        .from('code_sessions')
        .delete()
        .eq('id', sessionId);

      if (error) throw error;

      setHistory(prev => prev.filter(session => session.id !== sessionId));
      toast({
        title: "Deleted!",
        description: "Session has been removed from history.",
      });
    } catch (error) {
      console.error('Error deleting session:', error);
      toast({
        title: "Error",
        description: "Failed to delete session.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardContent className="flex items-center justify-center py-20">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          >
            <Bug className="h-8 w-8 text-purple-400" />
          </motion.div>
        </CardContent>
      </Card>
    );
  }

  if (history.length === 0) {
    return (
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardContent className="flex flex-col items-center justify-center py-20">
          <History className="h-16 w-16 text-gray-400 mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">No History Yet</h3>
          <p className="text-gray-300">Your analysis and fix history will appear here</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <History className="h-6 w-6 mr-2 text-purple-400" />
            Analysis History
          </CardTitle>
          <CardDescription className="text-gray-300">
            View and manage your previous code analyses and fixes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-gray-400">
            Total analyses: {history.length} | Fixed sessions: {history.filter(s => s.fix_results).length}
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {history.map((session, index) => (
          <motion.div
            key={session.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30 hover:border-purple-600/50 transition-all duration-300">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <Code className="h-6 w-6 text-purple-400" />
                    <div>
                      <CardTitle className="text-white text-lg">
                        {session.language} Code Session
                      </CardTitle>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {session.language}
                        </Badge>
                        <div className="flex items-center text-xs text-gray-400">
                          <Calendar className="h-3 w-3 mr-1" />
                          {new Date(session.created_at).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Badge className={`${getStatusColor(session)} text-white text-xs`}>
                      {getStatusText(session)}
                    </Badge>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => downloadCode(session)}
                        className="text-gray-400 hover:text-white p-2 h-auto"
                        title="Download"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteSession(session.id)}
                        className="text-gray-400 hover:text-red-400 p-2 h-auto"
                        title="Delete"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-400">
                      {session.analysis_results?.bugsFound || 0}
                    </div>
                    <div className="text-xs text-gray-400">Bugs Found</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">
                      {session.fix_results?.fixesApplied || 0}
                    </div>
                    <div className="text-xs text-gray-400">Fixes Applied</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">
                      {session.analysis_results?.bugsFound > 0 ? 
                        `${Math.round(((session.fix_results?.fixesApplied || 0) / session.analysis_results.bugsFound) * 100)}%` : 
                        '0%'}
                    </div>
                    <div className="text-xs text-gray-400">Success Rate</div>
                  </div>
                </div>
                
                <div className="bg-gray-900/80 rounded-lg p-3 border border-gray-700/50">
                  <div className="text-xs text-gray-400 mb-2">Code Preview:</div>
                  <pre className="text-xs text-gray-300 font-mono overflow-x-auto">
                    <code>{session.code_content.slice(0, 200)}...</code>
                  </pre>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export { HistoryPanel };
