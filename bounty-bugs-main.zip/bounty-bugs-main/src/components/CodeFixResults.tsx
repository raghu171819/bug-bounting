
import { useState } from "react";
import { motion } from "framer-motion";
import { Code, Download, Copy, Eye, EyeOff, CheckCircle, ArrowRight } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

interface CodeFixResultsProps {
  results: any;
  isLoading: boolean;
}

const CodeFixResults = ({ results, isLoading }: CodeFixResultsProps) => {
  const [showDiff, setShowDiff] = useState(true);
  const { toast } = useToast();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Code copied to clipboard.",
    });
  };

  const downloadCode = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Downloaded!",
      description: `${filename} has been downloaded.`,
    });
  };

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex flex-col items-center justify-center py-20"
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="mb-4"
        >
          <Code className="h-16 w-16 text-purple-400" />
        </motion.div>
        <h3 className="text-2xl font-bold text-white mb-2">Fixing Your Code</h3>
        <p className="text-gray-300">AI is generating minimal patches for detected bugs...</p>
      </motion.div>
    );
  }

  if (!results) {
    return (
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardContent className="flex flex-col items-center justify-center py-20">
          <Code className="h-16 w-16 text-gray-400 mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">No Fixes Yet</h3>
          <p className="text-gray-300">Run bug analysis first, then generate fixes!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Summary */}
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <CheckCircle className="h-6 w-6 mr-2 text-green-400" />
            Code Fixes Applied
          </CardTitle>
          <CardDescription className="text-gray-300">
            AI has successfully fixed all detected issues in your code
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">{results.fixesApplied}</div>
                <div className="text-sm text-gray-400">Fixes Applied</div>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => copyToClipboard(results.fixedCode)}
                className="border-purple-600/50 text-purple-300 hover:bg-purple-800/30"
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy Fixed Code
              </Button>
              <Button
                onClick={() => downloadCode(results.fixedCode, 'fixed-code.js')}
                className="bg-green-600 hover:bg-green-700"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Before/After Comparison */}
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">Code Comparison</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDiff(!showDiff)}
              className="text-gray-400 hover:text-white"
            >
              {showDiff ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
              {showDiff ? 'Hide Diff' : 'Show Diff'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="before" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-gray-800/50">
              <TabsTrigger value="before" className="text-white data-[state=active]:bg-red-600/50">
                Before (Original)
              </TabsTrigger>
              <TabsTrigger value="after" className="text-white data-[state=active]:bg-green-600/50">
                After (Fixed)
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="before" className="mt-4">
              <div className="bg-gray-900/80 rounded-lg p-4 border border-red-500/30">
                <pre className="text-sm text-gray-300 overflow-x-auto">
                  <code>{results.originalCode}</code>
                </pre>
              </div>
            </TabsContent>
            
            <TabsContent value="after" className="mt-4">
              <div className="bg-gray-900/80 rounded-lg p-4 border border-green-500/30">
                <pre className="text-sm text-gray-300 overflow-x-auto">
                  <code>{results.fixedCode}</code>
                </pre>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Detailed Changes */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-white">Detailed Changes</h3>
        {results.changes.map((change: any, index: number) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white text-lg">
                      Line {change.line} - {change.type}
                    </CardTitle>
                    <p className="text-gray-300 text-sm mt-1">{change.description}</p>
                  </div>
                  <Badge className="bg-blue-600 text-white">
                    Fixed
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-red-400 font-semibold">Before:</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(change.before)}
                        className="text-gray-400 hover:text-white p-1 h-auto"
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="bg-gray-900/80 rounded-lg p-3 border border-red-500/30">
                      <code className="text-sm text-gray-300 font-mono">
                        {change.before}
                      </code>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-green-400 font-semibold">After:</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(change.after)}
                        className="text-gray-400 hover:text-white p-1 h-auto"
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="bg-gray-900/80 rounded-lg p-3 border border-green-500/30">
                      <code className="text-sm text-gray-300 font-mono">
                        {change.after}
                      </code>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center text-sm text-gray-400">
                  <ArrowRight className="h-4 w-4 mr-2" />
                  This change improves code security and prevents potential vulnerabilities
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export { CodeFixResults };
