import { motion } from "framer-motion";
import { AlertTriangle, Shield, Zap, Bug, Copy, ExternalLink } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface BugAnalysisResultsProps {
  results: any;
  isLoading: boolean;
  onGenerateFixes?: () => void;
  isFixing?: boolean;
}

const BugAnalysisResults = ({ results, isLoading, onGenerateFixes, isFixing }: BugAnalysisResultsProps) => {
  const { toast } = useToast();

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "bg-red-500";
      case "medium": return "bg-yellow-500";
      case "low": return "bg-blue-500";
      default: return "bg-gray-500";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "Security": return Shield;
      case "Logic": return Bug;
      case "Performance": return Zap;
      default: return AlertTriangle;
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Code snippet copied to clipboard.",
    });
  };

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex flex-col items-center justify-center py-20"
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="mb-4"
        >
          <Bug className="h-16 w-16 text-purple-400" />
        </motion.div>
        <h3 className="text-2xl font-bold text-white mb-2">Analyzing Your Code</h3>
        <p className="text-gray-300">AI is scanning for bugs, vulnerabilities, and anti-patterns...</p>
      </motion.div>
    );
  }

  if (!results) {
    return (
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardContent className="flex flex-col items-center justify-center py-20">
          <Bug className="h-16 w-16 text-gray-400 mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">No Analysis Yet</h3>
          <p className="text-gray-300">Upload some code and click "Find Bugs" to get started!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Summary */}
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <AlertTriangle className="h-6 w-6 mr-2 text-purple-400" />
            Analysis Summary
          </CardTitle>
          <CardDescription className="text-gray-300">
            AI has completed the bug analysis of your code
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">{results.bugsFound}</div>
              <div className="text-sm text-gray-400">Issues Found</div>
            </div>
            <div className="flex space-x-2">
              {results.bugs.map((bug: any) => (
                <Badge
                  key={bug.id}
                  className={`${getSeverityColor(bug.severity)} text-white`}
                >
                  {bug.severity}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bug Details */}
      <div className="space-y-4">
        {results.bugs.map((bug: any, index: number) => {
          const TypeIcon = getTypeIcon(bug.type);
          
          return (
            <motion.div
              key={bug.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30 hover:border-purple-600/50 transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <TypeIcon className="h-6 w-6 text-purple-400" />
                      <div>
                        <CardTitle className="text-white text-lg">
                          {bug.title}
                        </CardTitle>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            Line {bug.line}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {bug.type}
                          </Badge>
                          <Badge className={`${getSeverityColor(bug.severity)} text-white text-xs`}>
                            {bug.severity}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(bug.code)}
                      className="text-gray-400 hover:text-white"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 mb-4">{bug.description}</p>
                  
                  <div className="bg-gray-900/80 rounded-lg p-4 border border-red-500/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-red-400 font-semibold">Problematic Code:</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(bug.code)}
                        className="text-gray-400 hover:text-white p-1 h-auto"
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <code className="text-sm text-gray-300 font-mono block whitespace-pre-wrap">
                      {bug.code}
                    </code>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Action Buttons */}
      <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
        <CardContent className="flex items-center justify-between p-6">
          <div>
            <h3 className="text-white font-semibold">Ready to fix these issues?</h3>
            <p className="text-gray-400 text-sm">AI can generate minimal patches for all detected bugs</p>
          </div>
          <Button 
            onClick={onGenerateFixes}
            disabled={isFixing || !results || results.bugs.length === 0}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {isFixing ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
              </motion.div>
            ) : (
              <ExternalLink className="h-4 w-4 mr-2" />
            )}
            {isFixing ? "Generating Fixes..." : "Generate Fixes"}
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export { BugAnalysisResults };
