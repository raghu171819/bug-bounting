
// Environment configuration utility
export const getApiKey = (): string => {
  const apiKey = import.meta.env.VITE_GOOGLE_API_KEY;
  
  if (!apiKey) {
    console.warn('Google API key not found in environment variables. Please set VITE_GOOGLE_API_KEY.');
    return '';
  }
  
  return apiKey;
};

export const validateEnvironment = (): boolean => {
  const requiredEnvVars = ['VITE_GOOGLE_API_KEY'];
  
  for (const envVar of requiredEnvVars) {
    if (!import.meta.env[envVar]) {
      console.error(`Missing required environment variable: ${envVar}`);
      return false;
    }
  }
  
  return true;
};
