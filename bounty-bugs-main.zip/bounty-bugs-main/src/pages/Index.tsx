
import { motion } from "framer-motion";
import { Bug, Shield, Code, Zap, ArrowRight, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white">
      {/* Navigation */}
      <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center space-x-2"
        >
          <Bug className="h-8 w-8 text-purple-400" />
          <span className="text-2xl font-bold">AI Bug Bounty</span>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-x-4"
        >
          <Link to="/auth">
            <Button variant="ghost" className="text-white hover:text-purple-300">
              Sign In
            </Button>
          </Link>
          <Link to="/auth">
            <Button className="bg-purple-600 hover:bg-purple-700">
              Get Started
            </Button>
          </Link>
        </motion.div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-20 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <motion.div
            animate={{ 
              rotate: 360,
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              rotate: { duration: 20, repeat: Infinity, ease: "linear" },
              scale: { duration: 2, repeat: Infinity }
            }}
            className="inline-block mb-8"
          >
            <Bug className="h-24 w-24 text-purple-400 mx-auto" />
          </motion.div>
          
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            AI-Powered Bug Hunter
          </h1>
          
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Upload your code and let our advanced AI scan for bugs, security vulnerabilities, 
            and anti-patterns. Get instant fixes with detailed explanations.
          </p>
          
          <Link to="/auth">
            <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-lg px-8 py-4">
              Start Hunting Bugs
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-6 py-20">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-center mb-16"
        >
          Powerful Features
        </motion.h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: Shield,
              title: "Security Analysis",
              description: "Advanced AI scans for security vulnerabilities and potential exploits in your code."
            },
            {
              icon: Code,
              title: "Logic Bug Detection",
              description: "Identifies logic errors, anti-patterns, and code smells that could cause issues."
            },
            {
              icon: Zap,
              title: "Instant Fixes",
              description: "Get minimal patch suggestions that fix bugs without changing your code structure."
            }
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border-purple-500/20 hover:border-purple-400/40 transition-all duration-300">
                <CardContent className="p-8 text-center">
                  <feature.icon className="h-12 w-12 text-purple-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-4">{feature.title}</h3>
                  <p className="text-gray-300">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container mx-auto px-6 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
          >
            <h2 className="text-4xl font-bold mb-8">Why Choose AI Bug Bounty?</h2>
            <div className="space-y-4">
              {[
                "AI-powered analysis finds bugs human reviewers miss",
                "Supports JavaScript, Python, and C programming languages",
                "Minimal patches preserve your code structure",
                "Detailed explanations help you learn from mistakes",
                "Save and track your bug hunting history"
              ].map((benefit, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center space-x-3"
                >
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span>{benefit}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            className="relative"
          >
            <div className="bg-gray-900 rounded-lg p-6 font-mono text-sm">
              <div className="text-green-400">// Before AI Analysis</div>
              <div className="text-gray-300 mt-2">
                {`function validateUser(user) {
  if (user.password == "admin") {
    return true;
  }
}`}
              </div>
              <div className="text-red-400 mt-4">// Bug: Weak password check</div>
              <div className="text-green-400 mt-4">// After AI Fix</div>
              <div className="text-gray-300 mt-2">
                {`function validateUser(user) {
  if (user.password === process.env.ADMIN_PASS) {
    return true;
  }
}`}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-6 py-20 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-2xl p-12 border border-purple-500/20"
        >
          <h2 className="text-4xl font-bold mb-6">Ready to Hunt Some Bugs?</h2>
          <p className="text-xl text-gray-300 mb-8">
            Join thousands of developers who trust AI Bug Bounty to secure their code
          </p>
          <Link to="/auth">
            <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-lg px-8 py-4">
              Start Your Free Analysis
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-6 py-8 text-center text-gray-400 border-t border-purple-800/30">
        <div className="flex items-center justify-center space-x-2">
          <Bug className="h-5 w-5" />
          <span>© 2024 AI Bug Bounty. Powered by advanced AI.</span>
        </div>
      </footer>
    </div>
  );
};

export default Index;
