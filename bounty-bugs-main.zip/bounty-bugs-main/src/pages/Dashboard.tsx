import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Bug, Search, Code, History, LogOut, Upload, FileText, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { analyzeBugs, generateFixes, AnalysisResults, FixResults } from "@/services/bugDetectionService";
import { BugAnalysisResults } from "@/components/BugAnalysisResults";
import { CodeFixResults } from "@/components/CodeFixResults";
import { HistoryPanel } from "@/components/HistoryPanel";
import type { Json } from "@/integrations/supabase/types";

const Dashboard = () => {
  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("javascript");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isFixing, setIsFixing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<AnalysisResults | null>(null);
  const [fixResults, setFixResults] = useState<FixResults | null>(null);
  const [activeTab, setActiveTab] = useState("upload");
  const { toast } = useToast();
  const { user, signOut, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Security: Validate file size and type
      if (file.size > 1024 * 1024) { // 1MB limit
        toast({
          title: "File too large",
          description: "Please upload a file smaller than 1MB.",
          variant: "destructive",
        });
        return;
      }

      const allowedTypes = ['.js', '.py', '.c', '.txt', '.java', '.php', '.ts', '.jsx', '.tsx'];
      const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
      
      if (!allowedTypes.includes(fileExtension)) {
        toast({
          title: "Invalid file type",
          description: "Please upload a supported code file.",
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        if (content.length > 50000) {
          toast({
            title: "File too large",
            description: "Please upload a file with less than 50,000 characters.",
            variant: "destructive",
          });
          return;
        }
        setCode(content);
        toast({
          title: "File uploaded!",
          description: "Your code has been loaded successfully.",
        });
      };
      reader.onerror = () => {
        toast({
          title: "Upload failed",
          description: "Failed to read the file. Please try again.",
          variant: "destructive",
        });
      };
      reader.readAsText(file);
    }
  };

  const handleFindBugs = async () => {
    // Input validation
    if (!code || code.trim().length === 0) {
      toast({
        title: "No code provided",
        description: "Please upload or paste some code to analyze.",
        variant: "destructive",
      });
      return;
    }

    if (code.length > 50000) {
      toast({
        title: "Code too large",
        description: "Please provide code with less than 50,000 characters.",
        variant: "destructive",
      });
      return;
    }

    console.log('Starting secure bug analysis...');
    setIsAnalyzing(true);
    setAnalysisResults(null);
    setFixResults(null);
    
    try {
      toast({
        title: "Analysis started",
        description: "AI is analyzing your code securely...",
      });
      
      const results = await analyzeBugs(code, language);
      console.log('Analysis completed successfully');
      
      setAnalysisResults(results);
      setActiveTab("results");
      
      // Secure database save
      if (user) {
        try {
          const { error } = await supabase.from('code_sessions').insert({
            user_id: user.id,
            code_content: code.substring(0, 50000), // Limit stored code size
            language: language,
            analysis_results: results as Json
          });
          
          if (error) {
            console.error('Database save error:', error);
          }
        } catch (dbError) {
          console.error('Database operation failed:', dbError);
        }
      }
      
      toast({
        title: "Analysis complete!",
        description: `Found ${results.bugsFound} potential issues in your code.`,
      });
    } catch (error) {
      console.error('Analysis error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Analysis failed';
      toast({
        title: "Analysis failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFixCode = async () => {
    if (!analysisResults || analysisResults.bugs.length === 0) {
      toast({
        title: "No bugs to fix",
        description: "Please run bug analysis first and ensure bugs are found.",
        variant: "destructive",
      });
      return;
    }

    console.log('Starting secure code fix generation...');
    setIsFixing(true);
    
    try {
      toast({
        title: "Generating fixes",
        description: "AI is creating secure patches for detected bugs...",
      });
      
      const fixes = await generateFixes(code, language, analysisResults.bugs);
      console.log('Fixes generated successfully');
      
      setFixResults(fixes);
      setActiveTab("fixes");
      
      // Secure database update
      if (user) {
        try {
          const { error } = await supabase.from('code_sessions')
            .update({ fix_results: fixes as Json })
            .eq('user_id', user.id)
            .eq('code_content', code);
            
          if (error) {
            console.error('Database update error:', error);
          }
        } catch (dbError) {
          console.error('Database update failed:', dbError);
        }
      }
      
      toast({
        title: "Code fixed!",
        description: `Applied ${fixes.fixesApplied} fixes to your code.`,
      });
    } catch (error) {
      console.error('Fix error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Fix generation failed';
      toast({
        title: "Fix generation failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsFixing(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Sign out error:', error);
      toast({
        title: "Sign out failed",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        >
          <Bug className="h-12 w-12 text-purple-400" />
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900">
      {/* Header */}
      <header className="border-b border-purple-800/30 bg-black/20 backdrop-blur-lg">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Bug className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">AI Bug Bounty</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="bg-purple-600 text-white">
              {user.email}
            </Badge>
            <Button variant="ghost" size="sm" className="text-white hover:text-purple-300" onClick={handleSignOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">Bug Hunter Dashboard</h1>
          <p className="text-gray-300">Upload your code and let AI find and fix bugs securely</p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-black/20 backdrop-blur-lg border border-purple-800/30">
            <TabsTrigger value="upload" className="text-white data-[state=active]:bg-purple-600">
              <Upload className="h-4 w-4 mr-2" />
              Upload Code
            </TabsTrigger>
            <TabsTrigger value="results" className="text-white data-[state=active]:bg-purple-600">
              <Search className="h-4 w-4 mr-2" />
              Bug Analysis
            </TabsTrigger>
            <TabsTrigger value="fixes" className="text-white data-[state=active]:bg-purple-600">
              <Code className="h-4 w-4 mr-2" />
              Code Fixes
            </TabsTrigger>
            <TabsTrigger value="history" className="text-white data-[state=active]:bg-purple-600">
              <History className="h-4 w-4 mr-2" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Code Input Panel */}
              <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    Code Input
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    Upload a file or paste your code directly (max 50,000 characters)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="w-40 bg-purple-800/30 border-purple-600/50 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="javascript">JavaScript</SelectItem>
                        <SelectItem value="typescript">TypeScript</SelectItem>
                        <SelectItem value="python">Python</SelectItem>
                        <SelectItem value="c">C</SelectItem>
                        <SelectItem value="java">Java</SelectItem>
                        <SelectItem value="php">PHP</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <div className="flex-1">
                      <input
                        type="file"
                        id="file-upload"
                        className="hidden"
                        accept=".js,.py,.c,.txt,.java,.php,.ts,.jsx,.tsx"
                        onChange={handleFileUpload}
                      />
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById('file-upload')?.click()}
                        className="w-full border-purple-600/50 text-purple-300 hover:bg-purple-800/30"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload File (max 1MB)
                      </Button>
                    </div>
                  </div>
                  
                  <Textarea
                    placeholder="Or paste your code here..."
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="min-h-[300px] bg-gray-900/50 border-purple-600/30 text-white font-mono"
                    maxLength={50000}
                  />
                  
                  <div className="text-xs text-gray-400">
                    Characters: {code.length}/50,000
                  </div>
                </CardContent>
              </Card>

              {/* Action Panel */}
              <Card className="bg-black/20 backdrop-blur-lg border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Zap className="h-5 w-5 mr-2" />
                    Secure AI Analysis
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    Let AI scan your code for bugs and vulnerabilities securely
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button
                    onClick={handleFindBugs}
                    disabled={isAnalyzing || !code.trim()}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-lg py-6"
                  >
                    {isAnalyzing ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      >
                        <Search className="h-5 w-5 mr-2" />
                      </motion.div>
                    ) : (
                      <Search className="h-5 w-5 mr-2" />
                    )}
                    {isAnalyzing ? "Analyzing Code..." : "Find Bugs"}
                  </Button>
                  
                  <Button
                    onClick={handleFixCode}
                    disabled={isFixing || !analysisResults || analysisResults.bugs.length === 0}
                    variant="outline"
                    className="w-full border-purple-600/50 text-purple-300 hover:bg-purple-800/30 text-lg py-6"
                  >
                    {isFixing ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      >
                        <Code className="h-5 w-5 mr-2" />
                      </motion.div>
                    ) : (
                      <Code className="h-5 w-5 mr-2" />
                    )}
                    {isFixing ? "Fixing Code..." : "Fix My Code"}
                  </Button>
                  
                  <div className="text-sm text-gray-400 mt-4">
                    <p>✓ Supports JavaScript, TypeScript, Python, C, Java, PHP</p>
                    <p>✓ Secure API key handling</p>
                    <p>✓ Input validation and sanitization</p>
                    <p>✓ File size and type restrictions</p>
                    <p>✓ Detects security vulnerabilities</p>
                    <p>✓ Generates AI-powered fix patches</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="results">
            <BugAnalysisResults 
              results={analysisResults} 
              isLoading={isAnalyzing}
              onGenerateFixes={handleFixCode}
              isFixing={isFixing}
            />
          </TabsContent>

          <TabsContent value="fixes">
            <CodeFixResults results={fixResults} isLoading={isFixing} />
          </TabsContent>

          <TabsContent value="history">
            <HistoryPanel />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Dashboard;
